'use client';

import { useEffect, useRef, useState, useCallback } from 'react';

export interface Ad {
  id: string;
  title: string;
  description?: string | null;
  imageUrl?: string | null;
  linkUrl?: string | null;
  linkText?: string | null;
  position: string;
  type: string;
  bgColor?: string | null;
  textColor?: string | null;
  accentColor?: string | null;
}

interface AdBannerProps {
  ads: Ad[];
  position: string;
}

function trackClick(id: string) {
  fetch(`/api/admin/ads/${id}/click`, { method: 'POST' }).catch(() => {});
}

// ─── Individual ad renderers ────────────────────────────────────────────────

function BannerAd({ ad, compact }: { ad: Ad; compact?: boolean }) {
  const bg = ad.bgColor || '#1a3c5e';
  const text = ad.textColor || '#ffffff';
  const accent = ad.accentColor || '#f4a61d';
  return (
    <div
      className={`w-full h-full rounded-2xl overflow-hidden flex items-center ${compact ? 'px-5 py-4' : 'px-8 py-7'}`}
      style={{ background: bg }}
    >
      {ad.imageUrl && (
        <div className={`hidden md:block rounded-xl overflow-hidden flex-shrink-0 mr-5 ${compact ? 'w-12 h-12' : 'w-20 h-20'}`}>
          <img src={ad.imageUrl} alt="" className="w-full h-full object-cover" />
        </div>
      )}
      <div className="flex-1 min-w-0">
        <p className={`font-bold uppercase tracking-widest opacity-50 mb-0.5 ${compact ? 'text-[9px]' : 'text-xs'}`} style={{ color: text }}>
          Sponsored
        </p>
        <p className={`font-extrabold leading-tight ${compact ? 'text-base' : 'text-xl md:text-2xl'}`} style={{ color: text }}>
          {ad.title}
        </p>
        {ad.description && !compact && (
          <p className="text-sm mt-1 opacity-75" style={{ color: text }}>{ad.description}</p>
        )}
      </div>
      {ad.linkUrl && (
        <a
          href={ad.linkUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => trackClick(ad.id)}
          className={`flex-shrink-0 ml-4 rounded-xl font-bold transition-opacity hover:opacity-90 whitespace-nowrap ${compact ? 'px-4 py-2 text-xs' : 'px-6 py-3 text-sm'}`}
          style={{ background: accent, color: '#1a1a1a' }}
        >
          {ad.linkText || 'Learn More →'}
        </a>
      )}
    </div>
  );
}

function CardAd({ ad, compact }: { ad: Ad; compact?: boolean }) {
  const accent = ad.accentColor || '#002045';
  return (
    <div className={`w-full h-full border border-[#e8e8e8] rounded-2xl bg-white flex items-center gap-4 ${compact ? 'px-4 py-3' : 'px-5 py-4'}`}>
      {ad.imageUrl && (
        <div className="w-10 h-10 rounded-xl overflow-hidden flex-shrink-0">
          <img src={ad.imageUrl} alt="" className="w-full h-full object-cover" />
        </div>
      )}
      <div className="flex-1 min-w-0">
        <p className="text-[9px] font-bold uppercase tracking-widest text-[#ccc] mb-0.5">Sponsored</p>
        <p className={`font-bold text-[#111] truncate ${compact ? 'text-xs' : 'text-sm'}`}>{ad.title}</p>
        {ad.description && (
          <p className="text-[11px] text-[#888] truncate">{ad.description}</p>
        )}
      </div>
      {ad.linkUrl && (
        <a
          href={ad.linkUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => trackClick(ad.id)}
          className="text-xs font-semibold hover:underline flex-shrink-0"
          style={{ color: accent }}
        >
          {ad.linkText || 'Learn more →'}
        </a>
      )}
    </div>
  );
}

function StripAd({ ad, compact }: { ad: Ad; compact?: boolean }) {
  const accent = ad.accentColor || '#7c3aed';
  return (
    <div className={`w-full h-full border border-[#e6e6e6] rounded-2xl bg-white flex items-center justify-between gap-4 ${compact ? 'px-4 py-3' : 'px-6 py-4'}`}>
      <div className="flex items-center gap-3 min-w-0">
        {ad.imageUrl && (
          <div className="w-9 h-9 rounded-lg overflow-hidden flex-shrink-0">
            <img src={ad.imageUrl} alt="" className="w-full h-full object-cover" />
          </div>
        )}
        <div className="min-w-0">
          <p className="text-[9px] font-bold uppercase tracking-widest text-[#ccc] mb-0.5">Sponsored</p>
          <p className={`font-bold text-[#111] truncate ${compact ? 'text-xs' : 'text-sm'}`}>{ad.title}</p>
          {ad.description && !compact && (
            <p className="text-[11px] text-[#888] truncate">{ad.description}</p>
          )}
        </div>
      </div>
      {ad.linkUrl && (
        <a
          href={ad.linkUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => trackClick(ad.id)}
          className="text-white text-xs font-semibold px-4 py-2 rounded-lg hover:opacity-90 transition-opacity flex-shrink-0"
          style={{ background: accent }}
        >
          {ad.linkText || 'Learn more →'}
        </a>
      )}
    </div>
  );
}

// ─── Single ad renderer ──────────────────────────────────────────────────────
function renderAd(ad: Ad, compact = false) {
  if (ad.type === 'card_row') return <CardAd key={ad.id} ad={ad} compact={compact} />;
  if (ad.type === 'strip') return <StripAd key={ad.id} ad={ad} compact={compact} />;
  return <BannerAd key={ad.id} ad={ad} compact={compact} />;
}

// ─── Carousel wrapper ────────────────────────────────────────────────────────
const CAROUSEL_INTERVAL = 5000; // ms

function AdCarousel({ ads, isTopBanner }: { ads: Ad[]; isTopBanner?: boolean }) {
  const [current, setCurrent] = useState(0);
  const [animating, setAnimating] = useState(false);
  const [direction, setDirection] = useState<'next' | 'prev'>('next');
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const goTo = useCallback((index: number, dir: 'next' | 'prev' = 'next') => {
    if (animating) return;
    setDirection(dir);
    setAnimating(true);
    setTimeout(() => {
      setCurrent(index);
      setAnimating(false);
    }, 380);
  }, [animating]);

  const next = useCallback(() => {
    goTo((current + 1) % ads.length, 'next');
  }, [current, ads.length, goTo]);

  const prev = useCallback(() => {
    goTo((current - 1 + ads.length) % ads.length, 'prev');
  }, [current, ads.length, goTo]);

  useEffect(() => {
    if (ads.length <= 1) return;
    timerRef.current = setTimeout(next, CAROUSEL_INTERVAL);
    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  }, [current, next, ads.length]);

  const translateClass = animating
    ? direction === 'next' ? '-translate-x-4 opacity-0' : 'translate-x-4 opacity-0'
    : 'translate-x-0 opacity-100';

  return (
    <div className={`relative w-full overflow-hidden ${isTopBanner ? '' : 'rounded-2xl'}`}>
      {/* Ad slide */}
      <div
        className={`transition-all duration-380 ease-in-out ${translateClass}`}
        style={{ transitionDuration: '380ms' }}
      >
        {renderAd(ads[current], isTopBanner)}
      </div>

      {/* Dots + arrows — only when multiple ads */}
      {ads.length > 1 && (
        <div className="absolute bottom-2.5 right-3 flex items-center gap-2">
          <button
            onClick={prev}
            className="w-6 h-6 rounded-full bg-black/20 hover:bg-black/40 flex items-center justify-center transition-colors"
            aria-label="Previous"
          >
            <span className="material-symbols-outlined text-white" style={{ fontSize: 14 }}>chevron_left</span>
          </button>
          <div className="flex items-center gap-1">
            {ads.map((_, i) => (
              <button
                key={i}
                onClick={() => goTo(i, i > current ? 'next' : 'prev')}
                className={`rounded-full transition-all duration-300 ${i === current ? 'w-5 h-1.5 bg-white' : 'w-1.5 h-1.5 bg-white/40 hover:bg-white/70'}`}
                aria-label={`Go to ad ${i + 1}`}
              />
            ))}
          </div>
          <button
            onClick={next}
            className="w-6 h-6 rounded-full bg-black/20 hover:bg-black/40 flex items-center justify-center transition-colors"
            aria-label="Next"
          >
            <span className="material-symbols-outlined text-white" style={{ fontSize: 14 }}>chevron_right</span>
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Top banner (between header and hero) ───────────────────────────────────
function TopBannerStrip({ ads }: { ads: Ad[] }) {
  if (ads.length === 0) return null;

  // 1 ad → plain strip; 2 ads → side by side; 3+ → carousel
  if (ads.length === 1) {
    return (
      <div className="w-full bg-[#0d1f36]">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-2.5 flex items-center justify-between gap-4">
          <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">Sponsored</p>
          <div className="flex-1 flex items-center justify-center gap-3">
            {ads[0].imageUrl && (
              <img src={ads[0].imageUrl} alt="" className="w-6 h-6 rounded-full object-cover" />
            )}
            <p className="text-sm font-semibold text-white truncate">{ads[0].title}</p>
            {ads[0].description && (
              <p className="text-xs text-white/60 hidden md:block truncate">— {ads[0].description}</p>
            )}
          </div>
          {ads[0].linkUrl && (
            <a
              href={ads[0].linkUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackClick(ads[0].id)}
              className="flex-shrink-0 text-xs font-bold px-4 py-1.5 rounded-lg transition-opacity hover:opacity-90"
              style={{ background: ads[0].accentColor || '#f4a61d', color: '#1a1a1a' }}
            >
              {ads[0].linkText || 'Learn More →'}
            </a>
          )}
        </div>
      </div>
    );
  }

  if (ads.length === 2) {
    return (
      <div className="w-full border-b border-[#e8e8e8] bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-2 grid grid-cols-2 gap-3">
          {ads.map((ad) => (
            <div key={ad.id} className="flex items-center gap-3 min-w-0">
              <p className="text-[9px] font-bold uppercase tracking-widest text-[#ccc] flex-shrink-0">Ad</p>
              {ad.imageUrl && (
                <img src={ad.imageUrl} alt="" className="w-6 h-6 rounded-full object-cover flex-shrink-0" />
              )}
              <p className="text-xs font-semibold text-[#191c1e] truncate flex-1">{ad.title}</p>
              {ad.linkUrl && (
                <a
                  href={ad.linkUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => trackClick(ad.id)}
                  className="text-[11px] font-bold px-3 py-1 rounded-lg flex-shrink-0 hover:opacity-90 transition-opacity"
                  style={{ background: ad.accentColor || '#002045', color: '#fff' }}
                >
                  {ad.linkText || 'View →'}
                </a>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 3+ ads → carousel strip
  return (
    <div className="w-full bg-[#0d1f36] overflow-hidden">
      <AdCarousel ads={ads} isTopBanner />
    </div>
  );
}

// ─── Main export ─────────────────────────────────────────────────────────────
export default function AdBanner({ ads, position }: AdBannerProps) {
  const positionAds = ads.filter((a) => a.position === position);
  if (positionAds.length === 0) return null;

  // Special handling for the top-of-page strip
  if (position === 'below_header') {
    return <TopBannerStrip ads={positionAds} />;
  }

  const count = positionAds.length;

  // 1 ad → render directly
  if (count === 1) {
    return (
      <div className="my-2">
        {renderAd(positionAds[0])}
      </div>
    );
  }

  // 2 ads → side-by-side row
  if (count === 2) {
    return (
      <div className="my-2 grid grid-cols-1 md:grid-cols-2 gap-3">
        {positionAds.map((ad) => (
          <div key={ad.id} className="h-full">
            {renderAd(ad, true)}
          </div>
        ))}
      </div>
    );
  }

  // 3 ads → three-column row
  if (count === 3) {
    return (
      <div className="my-2 grid grid-cols-1 md:grid-cols-3 gap-3">
        {positionAds.map((ad) => (
          <div key={ad.id} className="h-full">
            {renderAd(ad, true)}
          </div>
        ))}
      </div>
    );
  }

  // 4+ ads → auto carousel
  return (
    <div className="my-2">
      <AdCarousel ads={positionAds} />
    </div>
  );
}
