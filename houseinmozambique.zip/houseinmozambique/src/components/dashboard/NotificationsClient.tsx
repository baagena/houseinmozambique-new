'use client';

import { useMemo, useState } from 'react';
import { useLanguage } from '@/components/i18n/LanguageContext';

type NotificationKind = 'lead' | 'approval' | 'payment' | 'system';

interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  kind: NotificationKind;
  unread: boolean;
}

const notifications: NotificationItem[] = [
  {
    id: 'lead-1',
    title: 'New lead inquiry',
    message: 'A buyer requested more details about one of your active listings.',
    time: 'Today',
    kind: 'lead',
    unread: true,
  },
  {
    id: 'approval-1',
    title: 'Listing review update',
    message: 'Your latest property submission is queued for editorial review.',
    time: 'Yesterday',
    kind: 'approval',
    unread: true,
  },
  {
    id: 'payment-1',
    title: 'Payment reference received',
    message: 'Your manual payment reference was recorded and is awaiting confirmation.',
    time: 'This week',
    kind: 'payment',
    unread: false,
  },
  {
    id: 'system-1',
    title: 'Profile visibility',
    message: 'Complete your contact details to improve agent profile trust signals.',
    time: 'This month',
    kind: 'system',
    unread: false,
  },
];

const iconByKind: Record<NotificationKind, string> = {
  lead: 'forum',
  approval: 'task_alt',
  payment: 'payments',
  system: 'manage_accounts',
};

export default function NotificationsClient() {
  const { t } = useLanguage();
  const [showUnreadOnly, setShowUnreadOnly] = useState(false);
  const [readIds, setReadIds] = useState<string[]>([]);

  const visibleNotifications = useMemo(() => {
    return notifications
      .map((item) => ({ ...item, unread: item.unread && !readIds.includes(item.id) }))
      .filter((item) => (showUnreadOnly ? item.unread : true));
  }, [readIds, showUnreadOnly]);

  const unreadCount = visibleNotifications.filter((item) => item.unread).length;

  return (
    <section className="space-y-8">
      <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="mb-3 text-xs font-black uppercase tracking-[0.2em] text-[#845326]">
            {t.dashboard.notifications.title}
          </p>
          <h1 className="text-4xl font-extrabold tracking-tighter text-[#002045]" style={{ fontFamily: 'var(--font-headline)' }}>
            {t.dashboard.notifications.allNotifications}
          </h1>
          <p className="mt-2 max-w-2xl text-sm font-medium leading-relaxed text-[#43474e]/70">
            {t.dashboard.notifications.desc}
          </p>
        </div>

        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            onClick={() => setShowUnreadOnly((current) => !current)}
            className={`rounded-xl px-5 py-3 text-xs font-black uppercase tracking-widest transition-all ${
              showUnreadOnly
                ? 'bg-[#002045] text-white shadow-lg shadow-[#002045]/10'
                : 'border border-[#c4c6cf]/30 bg-white text-[#002045] hover:bg-[#f2f4f6]'
            }`}
          >
            {t.dashboard.notifications.unread}
          </button>
          <button
            type="button"
            onClick={() => setReadIds(notifications.map((item) => item.id))}
            className="rounded-xl bg-[#febc85] px-5 py-3 text-xs font-black uppercase tracking-widest text-[#002045] transition-all hover:bg-[#f4a96c]"
          >
            {t.dashboard.notifications.markAllAsRead}
          </button>
        </div>
      </div>

      <div className="grid gap-4">
        {visibleNotifications.map((item) => (
          <article
            key={item.id}
            className="flex gap-4 rounded-2xl border border-[#c4c6cf]/20 bg-white p-5 shadow-sm"
          >
            <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl ${item.unread ? 'bg-[#002045] text-[#febc85]' : 'bg-[#f2f4f6] text-[#74777f]'}`}>
              <span className="material-symbols-outlined">{iconByKind[item.kind]}</span>
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                <h2 className="text-sm font-black text-[#002045]">{item.title}</h2>
                <span className="text-[10px] font-black uppercase tracking-widest text-[#74777f]">{item.time}</span>
              </div>
              <p className="mt-2 text-sm font-medium leading-relaxed text-[#43474e]/70">{item.message}</p>
            </div>
            {item.unread && <span className="mt-2 h-2.5 w-2.5 shrink-0 rounded-full bg-red-500" />}
          </article>
        ))}
      </div>

      {visibleNotifications.length === 0 && (
        <div className="rounded-2xl border border-dashed border-[#c4c6cf]/40 bg-white py-16 text-center">
          <span className="material-symbols-outlined text-5xl text-[#c4c6cf]">notifications_off</span>
          <h2 className="mt-4 text-lg font-black text-[#002045]">{t.dashboard.notifications.noNotifications}</h2>
          <p className="mt-2 text-sm font-medium text-[#74777f]">
            {unreadCount === 0 ? t.dashboard.notifications.markAllAsRead : t.dashboard.notifications.desc}
          </p>
        </div>
      )}
    </section>
  );
}
