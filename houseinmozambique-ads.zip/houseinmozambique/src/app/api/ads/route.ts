import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET() {
  const ads = await prisma.advertisement.findMany({
    where: { isActive: true },
    orderBy: [{ position: 'asc' }, { sortOrder: 'asc' }],
  });
  return NextResponse.json(ads);
}
