'use client';

interface Ad {
  id: string;
  title: string;
  description?: string | null;
  imageUrl?: string | null;
  linkUrl?: string | null;
  linkText?: string | null;
  position: string;
  type: string;
  bgColor?: string | null;
  textColor?: string | null;
  accentColor?: string | null;
}

interface AdBannerProps {
  ads: Ad[];
  position: string;
}

function trackClick(id: string) {
  fetch(`/api/admin/ads/${id}/click`, { method: 'POST' }).catch(() => {});
}

function BannerAd({ ad }: { ad: Ad }) {
  const bg = ad.bgColor || '#1a3c5e';
  const text = ad.textColor || '#ffffff';
  const accent = ad.accentColor || '#f4a61d';

  return (
    <div className="w-full rounded-2xl overflow-hidden" style={{ background: bg }}>
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 px-8 py-7">
        {ad.imageUrl && (
          <div className="hidden md:block w-20 h-20 rounded-xl overflow-hidden flex-shrink-0">
            <img src={ad.imageUrl} alt="" className="w-full h-full object-cover" />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <p className="text-xs font-bold uppercase tracking-widest mb-1 opacity-60" style={{ color: text }}>
            Sponsored
          </p>
          <p className="text-xl md:text-2xl font-extrabold leading-tight" style={{ color: text }}>
            {ad.title}
          </p>
          {ad.description && (
            <p className="text-sm mt-1 opacity-75" style={{ color: text }}>
              {ad.description}
            </p>
          )}
        </div>
        {ad.linkUrl && (
          <a
            href={ad.linkUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => trackClick(ad.id)}
            className="flex-shrink-0 px-6 py-3 rounded-xl font-bold text-sm transition-opacity hover:opacity-90"
            style={{ background: accent, color: '#1a1a1a' }}
          >
            {ad.linkText || 'Learn More →'}
          </a>
        )}
      </div>
    </div>
  );
}

function CardRowAd({ ad }: { ad: Ad }) {
  const accent = ad.accentColor || '#002045';
  return (
    <div className="border border-[#e8e8e8] rounded-2xl p-5 bg-white flex flex-col sm:flex-row items-start sm:items-center gap-4">
      {ad.imageUrl && (
        <div className="w-12 h-12 rounded-xl overflow-hidden flex-shrink-0">
          <img src={ad.imageUrl} alt="" className="w-full h-full object-cover" />
        </div>
      )}
      <div className="flex-1 min-w-0">
        <p className="text-[10px] font-bold uppercase tracking-widest text-[#aaa] mb-0.5">Sponsored</p>
        <p className="text-sm font-bold text-[#111]">{ad.title}</p>
        {ad.description && <p className="text-xs text-[#888] mt-0.5">{ad.description}</p>}
      </div>
      {ad.linkUrl && (
        <a
          href={ad.linkUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => trackClick(ad.id)}
          className="text-xs font-semibold hover:underline flex-shrink-0"
          style={{ color: accent }}
        >
          {ad.linkText || 'Learn more →'}
        </a>
      )}
    </div>
  );
}

function StripAd({ ad }: { ad: Ad }) {
  const accent = ad.accentColor || '#7c3aed';
  return (
    <div className="border border-[#e6e6e6] rounded-2xl px-6 py-4 bg-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div className="flex items-center gap-4">
        {ad.imageUrl && (
          <div className="w-10 h-10 rounded-lg overflow-hidden flex-shrink-0">
            <img src={ad.imageUrl} alt="" className="w-full h-full object-cover" />
          </div>
        )}
        <div>
          <p className="text-[10px] font-bold uppercase tracking-widest text-[#bbb] mb-0.5">Sponsored</p>
          <p className="text-sm font-bold text-[#111]">{ad.title}</p>
          {ad.description && <p className="text-xs text-[#888]">{ad.description}</p>}
        </div>
      </div>
      {ad.linkUrl && (
        <a
          href={ad.linkUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => trackClick(ad.id)}
          className="text-white text-xs font-semibold px-5 py-2 rounded-lg hover:opacity-90 transition-opacity flex-shrink-0"
          style={{ background: accent }}
        >
          {ad.linkText || 'Learn more →'}
        </a>
      )}
    </div>
  );
}

export default function AdBanner({ ads, position }: AdBannerProps) {
  const positionAds = ads.filter((a) => a.position === position);
  if (positionAds.length === 0) return null;

  return (
    <div className="space-y-3 my-2">
      {positionAds.map((ad) => {
        if (ad.type === 'card_row') return <CardRowAd key={ad.id} ad={ad} />;
        if (ad.type === 'strip') return <StripAd key={ad.id} ad={ad} />;
        return <BannerAd key={ad.id} ad={ad} />;
      })}
    </div>
  );
}
