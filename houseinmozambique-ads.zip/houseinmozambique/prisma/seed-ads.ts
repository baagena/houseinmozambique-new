import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding example advertisements…');

  // Clear existing ads first (optional — comment out if you want to keep existing)
  await prisma.advertisement.deleteMany();

  const ads = [
    // ─── after_featured: Bold mortgage banner ───
    {
      title: 'Finance Your Dream Home',
      description: 'Low interest rates from 7.5% — BCI Bank mortgage pre-approval in minutes',
      imageUrl: null,
      linkUrl: 'https://bci.co.mz',
      linkText: 'Get Pre-approved →',
      position: 'after_featured',
      type: 'banner',
      bgColor: '#1a3c5e',
      textColor: '#ffffff',
      accentColor: '#f4a61d',
      isActive: true,
      sortOrder: 0,
    },

    // ─── between_cities_1: Home insurance card ───
    {
      title: 'Home Insurance from 1,200 MT/mo',
      description: 'Protect your Mozambique property against fire, flood & theft — Seguradora Nacional',
      imageUrl: null,
      linkUrl: '#',
      linkText: 'Get a Quote →',
      position: 'between_cities_1',
      type: 'card_row',
      bgColor: '#ffffff',
      textColor: '#111111',
      accentColor: '#2a7d40',
      isActive: true,
      sortOrder: 0,
    },

    // ─── between_cities_2: Moving services card ───
    {
      title: 'Relocating to Mozambique?',
      description: 'Professional movers across all provinces — free quote within 24 hours',
      imageUrl: null,
      linkUrl: '#',
      linkText: 'Book Movers →',
      position: 'between_cities_2',
      type: 'card_row',
      bgColor: '#ffffff',
      textColor: '#111111',
      accentColor: '#845326',
      isActive: true,
      sortOrder: 0,
    },

    // ─── sidebar_strip: Virtual tours promo ───
    {
      title: 'View Any Listing in 3D — Virtual Tours Now Available',
      description: 'Tour properties from anywhere in the world before you fly in',
      imageUrl: null,
      linkUrl: '#',
      linkText: 'Try a Virtual Tour',
      position: 'sidebar_strip',
      type: 'strip',
      bgColor: '#ffffff',
      textColor: '#111111',
      accentColor: '#3a52c4',
      isActive: true,
      sortOrder: 0,
    },

    // ─── before_footer: Property listing upsell ───
    {
      title: 'List Your Property — Reach 50,000+ Monthly Buyers',
      description: 'Advertise on Houses in Mozambique and get qualified leads fast',
      imageUrl: null,
      linkUrl: '/post-property',
      linkText: 'List for Free →',
      position: 'before_footer',
      type: 'strip',
      bgColor: '#ffffff',
      textColor: '#111111',
      accentColor: '#7c3aed',
      isActive: true,
      sortOrder: 0,
    },
  ];

  for (const ad of ads) {
    await prisma.advertisement.create({ data: ad });
    console.log(`  ✓ Created: ${ad.title}`);
  }

  console.log(`\nDone — ${ads.length} ads seeded.`);
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
